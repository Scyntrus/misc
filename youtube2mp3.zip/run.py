import subprocess
import os
import re

url = raw_input("Input youtube URL: ").split("&")[0]
meta = subprocess.check_output(["youtube-dl", url, "-F"])
meta = meta.split("\n")[6:-1]
best = 0
bestfm = 0
fmstring = ""
for fm in meta:
    if "audio only" in fm:
        result = re.search("audio(.*?)k",fm[35:])
        if result:
            bitrate = int(result.group(1))
            if bitrate > best:
                best = bitrate
                bestfm = int(fm[0:13])
                fmstring = fm

print "Format:", fmstring

dldata = subprocess.check_output(["youtube-dl", url, "-f", str(bestfm)])
fname = dldata.split("[download] Destination: ")[1].split("\n")[0]
fname2 = fname.rsplit("-",1)[0] + ".mp3"
print "Downloaded:", fname

subprocess.check_output(["ffmpeg", "-i", fname, "-codec:a", "libmp3lame", "-q:a", "3", fname2])
print "Output:", fname2
os.remove(fname)
